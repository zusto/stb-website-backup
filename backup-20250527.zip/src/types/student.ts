export interface StudentData {
  firstName: string;
  middleName?: string;
  lastName: string;
  email: string;
  mobile: string;
  dateOfBirth: string;
  college?: string;
  // Add other relevant fields
}