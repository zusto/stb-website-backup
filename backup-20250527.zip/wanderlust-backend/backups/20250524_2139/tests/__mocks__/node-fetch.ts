const fetch = jest.fn();
export default fetch;