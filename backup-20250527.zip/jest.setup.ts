import { enableFetchMocks } from 'jest-fetch-mock';
enableFetchMocks();